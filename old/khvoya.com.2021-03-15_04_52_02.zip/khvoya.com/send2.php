<?php

header('Content-Type: application/json');

if ( isset($_COOKIE['nobot']) ) {

	$from = "noreply@khvoya.com";


	$to = "info@khvoya.com";
	$to2 = "khvoya.metrika@yandex.ru";

	$boundary = md5("sanwebe"); 

	$headers = "MIME-Version: 1.0\r\n"; 
	$headers .= "From:".$from."\r\n"; 
	$headers .= "Reply-To: ".$from."\r\n";
	$headers .= "X-Sender: ".$from." < ".$domain." >\n";
	$headers .= 'X-Mailer: PHP/' . phpversion();
	$headers .= "X-Priority: 1\n"; // Urgent message!
	$headers .= "Return-Path: ".$from."\n"; // Return path for errors
	$headers .= "Content-Type: multipart/mixed; charset = UTF-8; boundary = $boundary\r\n\r\n"; 

	$subject = mb_encode_mimeheader("Заявка с сайта ".$domain,"UTF-8");

	$message_body = "<html><head><title>Заявка с сайта ".$domain."</title></head><body>";
	$message_body .= "<p>Имя: " .$_POST['name']. "</p>";
	$message_body .= "<p>Телефон: " .$_POST['phone']. "</p>";
	$message_body .= "</body></html>";
	$message_body2 .= "";

	//plain text/plane
	$body = "--$boundary\r\n";
	$body .= "Content-Type: text/plane; charset=UTF-8\r\n";
	$body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
	$body .= chunk_split(base64_encode($message_body2)); 

	//plain text/html 
	$body .= "--$boundary\r\n";
	$body .= "Content-Type: text/html; charset=UTF-8\r\n";
	$body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
	$body .= chunk_split(base64_encode($message_body)); 



	mail($to, $subject, $body, $headers);
	mail($to2, $subject, $body, $headers);

	echo json_encode(true);
}	
?>
$(document).ready(function(){

	var scrollTopWindow = $(window).scrollTop();

	$(function () {
        $(window).scroll(function () {

        	 if ($(this).scrollTop() < ($('#about').offset().top - 80)) {
            	$('.top .menu li a').removeClass('active');
            }

            if ($(this).scrollTop() >= ($('#about').offset().top - 80) ) {
            	$('.top .menu li a').removeClass('active');
            	$('.top .menu li:nth-child(1) a').addClass('active');
            }

            if ($(this).scrollTop() >= ($('#services').offset().top - 80) ) {
            	$('.top .menu li a').removeClass('active');
                $('.top .menu li:nth-child(2) a').addClass('active');
            }

            if ($(this).scrollTop() >= ($('#portfolio').offset().top - 80) ) {
            	$('.top .menu li a').removeClass('active');
                $('.top .menu li:nth-child(3) a').addClass('active');
            }

            if ($(this).scrollTop() >= ($('#contacts').offset().top - 80) ) {
            	$('.top .menu li a').removeClass('active');
                $('.top .menu li:nth-child(4) a').addClass('active');
            }


            //ANIMATION

if ( $(window).width() > 768){
            if ($(this).scrollTop() > ($('.tree').offset().top - 800) ) {
            	$('ul.centered li:nth-child(1)').animate({
            		'opacity' : 1
            	}, 900);
            }


            if ($(this).scrollTop() > ($('ul.centered').offset().top - 660) ) {
            	$('ul.centered').animate({
            		'width' : 1,
            		'height' : '60%'
            	}, 1600);
            } 


            if ($(this).scrollTop() > ($('.tree').offset().top - 420) ) {
            	$('ul.centered li:nth-child(2)').animate({
            		'opacity' : 1
            	}, 900);
            }

            if ($(this).scrollTop() > ($('.tree').offset().top - 220) ) {
            	$('ul.centered li:nth-child(3)').animate({
            		'opacity' : 1
            	}, 900);
            }




            //1
            if ($(this).scrollTop() > ($('.tree').offset().top - 600) ) {
            	$('.tree').animate({
            		'opacity' : 1
            	}, 1200);
            }

            if ($(this).scrollTop() > ($('.tree').offset().top - 500) ) {
				$('.how ul.twoColumns.how1 li:last-child span').animate({
            		'top': 0,
            		'opacity' : 1
				},1200);
            }

            //2
            if ($(this).scrollTop() > ($('.tree').offset().top - 400) ) {
            	$('.house').animate({
            		'opacity' : 1
            	}, 1200);
            }

            if ($(this).scrollTop() > ($('.tree').offset().top - 300) ) {
				$('.how ul.twoColumns.how2 li:first-child span').animate({
            		'top': 0,
            		'opacity' : 1
				},1200);
            }

            //3
            if ($(this).scrollTop() > ($('.tree').offset().top - 200) ) {
            	$('.worker').animate({
            		'opacity' : 1
            	}, 1200);
            }

            if ($(this).scrollTop() > ($('.tree').offset().top - 100) ) {
				$('.how ul.twoColumns.how3 li:last-child span').animate({
            		'top': 0,
            		'opacity' : 1
				}, 1200);
            }
}


        });

         $('.top .logo').click(function(){
        	$('body,html').animate({scrollTop: 0}, 800);
        	return false;
        });


        $('.menu li a').click(function(){
        	var index = $(this).parent('li').index()+1;
        	if (index == 1) {
        		if ($(window).width() > 684){
        			pos = $('#about').offset().top - 60;
        		} else {
        			pos = $('#about').offset().top - 80;
        		}
        	}

        	if (index == 2) {
        		pos = $('#services').offset().top - 60;
        	}

        	if (index == 3) {
        		pos = $('#portfolio').offset().top - 60;
        	}

        	if (index == 4) {
        		pos = $('#contacts').offset().top - 60;
        	}
        	$('body,html').animate({scrollTop: pos}, 800);
        	
        	return false;
        });
    });
	$('.mobile_menu .menu li a').click(function(){
    	$('.mobile_menu').toggle();
    });



	
	$('ul.switch li').click(function(){
		var num = $(this).index() + 1;
		$('ul.switch li').removeClass('active');

		$(this).addClass('active');
		$('.tabs').hide();
		$('.tab'+num).show();

	});


	$('ul.tabFeed li').click(function(){
		var id = $(this).attr('data-id');
		$('ul.tabFeed li').removeClass('active');

		$(this).addClass('active');
		$('.mainFeed').hide();
		$('.mainFeed#'+id).show();

	});


	//BURGER
	$('.burger, .closemenu').click(function(){
        $('.mobile_menu').toggle();
    });

	//PHONE MASK
	$('input[name=phone]').inputmask("+7 (999) 999-99-99");





	//POPUP
	$('.popup').css({
		'left': $(window).width() * 0.5 - $('.popup').width() * 0.5,
		'top' : $(window).height() * 0.5 - $('.popup').height() * 0.5
	});


	$('.openform').click(function() {
		var scrollTopWindow = $(window).scrollTop();

		$('.fog').css({
		    'display' : 'block',
		    'width' : $(window).width(),
		    'height' : $(document).height()
		});

		$('.fog').show().addClass('bggreen').removeClass('bgwhite');

		$('.popupform').animate({
		    'left' : $(window).width() * 0.5 - $('.popupform').width() * 0.5
			},0).fadeIn(300).animate({
			'top' : scrollTopWindow + 100
		},200);

		$('.popupform').css({'display' : 'block'});

	});


	//CLOSE
	$('.closeform, .fog').click(function() {
		var scrollTopWindow = $(window).scrollTop();

		$('.fog').css({
		  'display' : 'none',
		  'width' : $(window).width(),
		  'height' : $(document).height()
		});

		$('.popup').css({
		  'display' : 'none',
		  'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
		  'top' : scrollTopWindow + 100
		});

	});


	//RESIZE
	$(window).resize(function(){
		var scrollTopWindow = $(window).scrollTop();

	    $('.popup').css({
	        'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
	        'top' : scrollTopWindow + 100
	    });

		$('.fog').css({
		  'width' : $(window).width(),
		  'height' : $(document).height()
		});

	  });


	//FORM SEND
	/*$('.popupform .send, .form .send, .feedback button').click(function(e) {
		var scrollTopWindow = $(window).scrollTop();
		$('.popup').css({
	        'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
	        'top' : scrollTopWindow + 100
	    });
		$('.popupsuccess').show();
        $('.popupform').hide();

        $('.fog').show();
        $('.fog').removeClass('bggreen').addClass('bgwhite');
		return false;
	});*/



	$('.topForm').submit(function(e) {
		e.preventDefault();
		var phone = $(".topForm input[name='phone']").val();

		var dataString = 'phone=' + phone;

		//send
		if ( phone.length > 5 )  {
		    $.ajax({
		        type: "POST",
		        url: "/send.php",
		        data: dataString,
		        success: function() {
		            $('.popupsuccess').show();
		            $('.popupform').hide();
		            $('.fog').show().removeClass('bggreen').addClass('bgwhite');

					var scrollTopWindow = $(window).scrollTop();
		            $('.popup').css({
				        'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
				        'top' : scrollTopWindow + 100
				    });
		        },
		        error: function(){
		          $('.topForm .message').fadeIn(1000).html('Произошла ошибка. Попробуйте позднее.').delay(1000).fadeOut(500);
		        }
		    });
		} 
		return false;
	});



	$('.footerForm').submit(function(e) {
		e.preventDefault();
		var phone = $(".footerForm input[name='phone']").val();

		var dataString = 'phone=' + phone;

		//send
		if ( phone.length > 5 )  {
		    $.ajax({
		        type: "POST",
		        url: "/send.php",
		        data: dataString,
		        success: function() {
		            $('.popupsuccess').show();
		            $('.popupform').hide();
		            $('.fog').show().removeClass('bggreen').addClass('bgwhite');

					var scrollTopWindow = $(window).scrollTop();
		            $('.popup').css({
				        'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
				        'top' : scrollTopWindow + 100
				    });
		        },
		        error: function(){
		          $('.footerForm .message').fadeIn(1000).html('Произошла ошибка. Попробуйте позднее.').delay(1000).fadeOut(500);
		        }
		    });
		} 
		return false;
	});



	$('.popUpForm').submit(function(e) {
		e.preventDefault();
		var name = $(".popUpForm input[name='name']").val();
		var phone = $(".popUpForm input[name='phone']").val();

		var dataString = 'name=' + name + '&phone=' + phone;

		//send
		if ( (name.length > 1) && (phone.length > 5) )  {
		    $.ajax({
		        type: "POST",
		        url: "/send2.php",
		        data: dataString,
		        success: function() {
		            $('.popupsuccess').show();
		            $('.popupform').hide();
		            $('.fog').removeClass('bggreen').addClass('bgwhite');
		            
		            var scrollTopWindow = $(window).scrollTop();
		            $('.popup').css({
				        'left' : $(window).width() * 0.5 - $('.popup').width() * 0.5,
				        'top' : scrollTopWindow + 100
				    });
		        },
		        error: function(){
		          $('.popupform .message').fadeIn(1000).html('Произошла ошибка. Попробйте позднее.').delay(1000).fadeOut(500);
		        }
		    });
		} else {
		  	$('.popupform .message').fadeOut(0).fadeIn(500).html('Все поля обязательны к заполнению!').delay(1000).fadeOut(500);
		}
		return false;
	});



	//COOKIE NOBOT
	(function setCookie(n, v, o) {
		o = o || {};
		o.path = '/';
		var e = o.e;
		if (typeof e == "number" && e) {var d = new Date();d.setTime(d.getTime() + e * 1000);e = o.e = d;}
		if (e && e.toUTCString) {o.e = e.toUTCString();}
		v = encodeURIComponent(v);
		var u = n + "=" + v;
		for (var p in o) {
			u += "; " + p;var s = o[p];
			if (s !== true) {u += "=" + s;}
		}
		document.cookie = u;
	})('nobot', '1');


//STELLAR PARALLAX
if ( $(window).width() > 768){
	$(window).stellar({
	  horizontalScrolling: false,
	  verticalScrolling: true,
	  horizontalOffset: 0,
	  verticalOffset: 0,
	  responsive: true,
	  scrollProperty: 'scroll',
	  positionProperty: 'transform',
	  parallaxBackgrounds: true,
	  parallaxElements: true,
	  hideDistantElements: false,
	  hideElement: function($elem) { $elem.hide(); },
	  showElement: function($elem) { $elem.show(); }
	});

}

});


lightbox.option({
      'resizeDuration': 500,
      'fadeDuration': 300,
      'imageFadeDuration': 600,
      'wrapAround': true,
      'alwaysShowNavOnTouchDevices' : true
    })


